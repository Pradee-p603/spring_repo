package com.rays.primary;

public interface MessageService {
	public void sendMessage(String message);
}
