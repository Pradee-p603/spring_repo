package com.rays.autowire.bytype;

public interface UserDao {

	public void add();

}
