package com.rays.autowire.byconstructor;

public interface UserDao {

	public void add();

}
