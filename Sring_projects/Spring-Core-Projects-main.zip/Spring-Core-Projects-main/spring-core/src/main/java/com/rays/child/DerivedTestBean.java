package com.rays.child;

public class DerivedTestBean extends TestBean {

	public void initialize() {
		System.out.println("Initializing DerivedTestBean...");
	}
}
