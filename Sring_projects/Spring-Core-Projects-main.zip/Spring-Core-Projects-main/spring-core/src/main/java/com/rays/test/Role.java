package com.rays.test;

public class Role {

	public void doSomethingElse() {
		System.out.println("Doing something else...");
	}

}
