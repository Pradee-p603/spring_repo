package com.rays.autowire.byname;

public interface UserDao {

	public void add();

}
