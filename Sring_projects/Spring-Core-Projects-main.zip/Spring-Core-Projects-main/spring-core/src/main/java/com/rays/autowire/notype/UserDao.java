package com.rays.autowire.notype;

public interface UserDao {

	public void add();

}
