package com.rays.exclude;

public class AnotherService {

	public void doSomething() {
		System.out.println("Doing something...");
	}
}
