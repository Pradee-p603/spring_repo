package com.rays.autowire.bytype;

public class UserDaoImpl implements UserDao {

	public void add() {
		System.out.println("add method..!!!");
	}

}
