package com.rays.autowire.notype;

public class UserDaoImpl implements UserDao {

	public void add() {
		System.out.println("add method..!!!");
	}

}
