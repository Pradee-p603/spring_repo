package com.rays.autowire.byname;

public class UserDaoImpl implements UserDao {

	public void add() {
		System.out.println("add method..!!!");
	}

}
