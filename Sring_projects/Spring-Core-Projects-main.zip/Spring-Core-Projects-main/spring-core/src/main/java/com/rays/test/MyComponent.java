package com.rays.test;

import org.springframework.stereotype.Component;

@Component
public class MyComponent {

	public void doSomething() {
		System.out.println("Doing something...");
	}

}
