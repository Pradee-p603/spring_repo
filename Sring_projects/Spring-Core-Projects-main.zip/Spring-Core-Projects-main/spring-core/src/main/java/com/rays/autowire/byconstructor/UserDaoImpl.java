package com.rays.autowire.byconstructor;

public class UserDaoImpl implements UserDao {

	public void add() {
		System.out.println("add method..!!!");
	}

}
